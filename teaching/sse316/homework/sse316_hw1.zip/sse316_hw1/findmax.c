#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>

#define array_size 20  // The size of the array
#define num_elem_pp 5  // The number of elements per process
#define tag1 1
#define tag2 2

int array[array_size];
int subarray[num_elem_pp];

void generate_random_nums(int* array);
int find_subarray_max(int* subarray, int size);


int main(int argc, char **argv) {
    int proc_id;
    int proc_num;
    int array_max = 0;
    int worker_max = 0;
    double startTime = 0.0;
    double endTime;
    MPI_Status status;

    /* Initialize MPI and get the ID of the current process and the total number of processes */
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &proc_id);
    MPI_Comm_size(MPI_COMM_WORLD, &proc_num);

    /* Generate an array with random integers within [0, 1000] */
    srand(time(NULL));
    for (int i = 0; i < array_size; i++)
        array[i] = (int) ((double) rand() / RAND_MAX * 1000);

    /* The master process */
    if (proc_id == 0) {
        startTime = MPI_Wtime();

        // Distribute the array to the worker processes
        for (int j = 1; j < proc_num; j++) {
            int start_elem = j * num_elem_pp;
            int end_elem = start_elem + num_elem_pp;

            // #1 Fill in your code here

        }

        // The master process calculates the max element in its subarray
        array_max = find_subarray_max(array, num_elem_pp);

        // Get the results from the worker processes
        for(int k = 1; k < proc_num; k++){
            // #2 Fill in your code here

        }
        endTime = MPI_Wtime();
        printf("The max element found by MPI is %d (time elapsed: %fs)\n", array_max, (endTime-startTime));
        
        int true_array_max = find_subarray_max(array, array_size);
        printf("The true max element is %d\n", true_array_max);

    /* The worker processes */
    } else {
        // #3 Fill in your code here

    }

    MPI_Finalize();
}

/* The function to find the maximum element within an array of size subarray_size */
int find_subarray_max(int* subarray, int subarray_size) {
    if (subarray_size > 0) {
        int subarray_max = subarray[0];
        for (int i = 1; i < subarray_size; i++) {
            if (subarray[i] > subarray_max)
                subarray_max = subarray[i];
        }
        return subarray_max;
    }

    // Return the minimum value of int if the subarray is empty
    return INT_MIN;
}
